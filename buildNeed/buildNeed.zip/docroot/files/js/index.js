$(document).ready(function(){
	
	$(".signure").click(function(){
		console.log("in here");
	});
})